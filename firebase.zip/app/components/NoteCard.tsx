'use client';
import { useState } from "react";
import { db } from "../../lib/firebase";
import { doc, updateDoc, deleteDoc, serverTimestamp } from "firebase/firestore";

export default function NoteCard({ note, uid }: { note: any; uid: string }) {
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(note.title);
  const [body, setBody] = useState(note.body);

  const saveEdit = async () => {
    await updateDoc(doc(db, `users/${uid}/notes/${note.id}`), {
      title,
      body,
      updatedAt: serverTimestamp()
    });
    setEditing(false);
  };

  const deleteNote = async () => {
    await deleteDoc(doc(db, `users/${uid}/notes/${note.id}`));
  };

  return (
    <div style={{ border: "1px solid #ddd", padding: 12, marginBottom: 10, borderRadius: 6 }}>
      {editing ? (
        <>
          <input value={title} onChange={(e) => setTitle(e.target.value)} style={{ padding: 6, width: "100%", marginBottom: 6 }} />
          <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={3} style={{ padding: 6, width: "100%", marginBottom: 6 }} />
          <button onClick={saveEdit} style={{ marginRight: 8 }}>Save</button>
          <button onClick={() => setEditing(false)}>Cancel</button>
        </>
      ) : (
        <>
          <h3>{note.title}</h3>
          <p>{note.body}</p>
          <button onClick={() => setEditing(true)} style={{ marginRight: 8 }}>Edit</button>
          <button onClick={deleteNote}>Delete</button>
        </>
      )}
    </div>
  );
}