'use client';
import { useState, useEffect } from "react";
import { auth, db } from "../lib/firebase";
import { onAuthStateChanged, signOut, User } from "firebase/auth";
import { collection, query, orderBy, onSnapshot } from "firebase/firestore";
import { useRouter } from "next/navigation";
import NoteEditor from "./components/NoteEditor";
import NoteCard from "./components/NoteCard";

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [notes, setNotes] = useState<any[]>([]);
  const router = useRouter();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
      if (!currentUser) router.push("/login");
    });
    return () => unsubscribe();
  }, [router]);

  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, `users/${user.uid}/notes`),
      orderBy("updatedAt", "desc")
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setNotes(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })));
    });
    return () => unsubscribe();
  }, [user]);

  if (loading) return <p style={{ textAlign: "center", marginTop: 50 }}>Loading...</p>;
  if (!user) return null;

  return (
    <div style={{ maxWidth: 600, margin: "40px auto", padding: 20, fontFamily: "sans-serif" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h1>My Notes</h1>
        <button onClick={() => signOut(auth)} style={{ padding: 8 }}>Logout</button>
      </div>
      <NoteEditor uid={user.uid} />
      {notes.length === 0 && <p>No notes yet. Add one above!</p>}
      {notes.map((note) => (
        <NoteCard key={note.id} note={note} uid={user.uid} />
      ))}
    </div>
  );
}