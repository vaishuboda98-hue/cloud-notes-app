import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyC7TWrGzV9-Y4KHpnUaWkSjB0vujXhsTuQ",
  authDomain: "cloud-notes-app-855da.firebaseapp.com",
  projectId: "cloud-notes-app-855da",
  storageBucket: "cloud-notes-app-855da.firebasestorage.app",
  messagingSenderId: "727424238474",
  appId: "1:727424238474:web:48f38725dcc79b1e59be73",
  measurementId: "G-FSGCNJSMJL"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();
export const db = getFirestore(app);