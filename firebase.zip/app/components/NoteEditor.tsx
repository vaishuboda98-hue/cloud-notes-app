'use client';
import { useState } from "react";
import { db } from "../../lib/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

export default function NoteEditor({ uid }: { uid: string }) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    await addDoc(collection(db, `users/${uid}/notes`), {
      title,
      body,
      tags: [],
      shared: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    setTitle("");
    setBody("");
  };

  return (
    <form onSubmit={handleAdd} style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 20 }}>
      <input
        placeholder="Note title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        style={{ padding: 8 }}
      />
      <textarea
        placeholder="Write your note..."
        value={body}
        onChange={(e) => setBody(e.target.value)}
        rows={4}
        style={{ padding: 8 }}
      />
      <button type="submit" style={{ padding: 8 }}>Add Note</button>
    </form>
  );
}